package BO;

import DTO.Servico;
import DAO.ServicoDAO;
import java.util.List;

public class ServicoBO {

    public boolean inserir(Servico servico){
        if (existe(servico) != true) {
            ServicoDAO servicosDAO = new ServicoDAO();
            return servicosDAO.inserir(servico);
        }
        return false;
    }
    public boolean alterar(Servico servico){
        ServicoDAO servicosDAO = new ServicoDAO();
        return servicosDAO.alterar(servico);
    }
    public boolean excluir(Servico servico){
        ServicoDAO servicosDAO = new ServicoDAO();
        return servicosDAO.excluir(servico);
    }
    public Servico procurarPorId(Servico servico){
        ServicoDAO servicosDAO = new ServicoDAO();
        return servicosDAO.procurarPorId(servico);
    }
    public boolean existe(Servico servico){
        ServicoDAO servicosDAO = new ServicoDAO();
        return servicosDAO.existe(servico);
    }
    public List<Servico> pesquisarTodos(){
        ServicoDAO servicosDAO = new ServicoDAO();
        return servicosDAO.pesquisarTodos();
    }
}