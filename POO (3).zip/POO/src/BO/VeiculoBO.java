package BO;

import DTO.Peca;
import DTO.Veiculo;
import DAO.VeiculoDAO;
import java.util.List;

public class VeiculoBO {

    public boolean inserir(Veiculo veiculo){
        if (existe(veiculo) != true) {
            VeiculoDAO veiculosDAO = new VeiculoDAO();
            return veiculosDAO.inserir(veiculo);
        }
        return false;
    }
    public boolean alterar(Veiculo veiculo){
        VeiculoDAO veiculosDAO = new VeiculoDAO();
        return veiculosDAO.alterar(veiculo);
    }
    public boolean excluir(Veiculo veiculo){
        VeiculoDAO veiculosDAO = new VeiculoDAO();
        return veiculosDAO.excluir(veiculo);
    }
    public Veiculo procurarPorId(Veiculo veiculo){
        VeiculoDAO veiculosDAO = new VeiculoDAO();
        return veiculosDAO.procurarPorId(veiculo);
    }
    public boolean existe(Veiculo veiculo){
        VeiculoDAO veiculosDAO = new VeiculoDAO();
        return veiculosDAO.existe(veiculo);
    }
    public List<Veiculo> pesquisarTodos(){
        VeiculoDAO veiculosDAO = new VeiculoDAO();
        return veiculosDAO.pesquisarTodos();
    }

    public boolean inserirJuncaoPeca(Veiculo veiculo, Peca peca){
        if (existeJuncaoPeca(veiculo, peca) != true) {
            VeiculoDAO veiculosDAO = new VeiculoDAO();
            return veiculosDAO.inserirJuncaoPeca(veiculo, peca);
        }
        return false;
    }

    public boolean excluirJuncaoPeca(Veiculo veiculo){
        VeiculoDAO veiculosDAO = new VeiculoDAO();
        return veiculosDAO.excluirJuncaoPeca(veiculo);
    }
    public boolean excluirJuncaoPeca(Veiculo veiculo, Peca peca){
        VeiculoDAO veiculosDAO = new VeiculoDAO();
        return veiculosDAO.excluirJuncaoPeca(veiculo, peca);
    }
    public boolean existeJuncaoPeca(Veiculo veiculo, Peca peca){
        VeiculoDAO veiculosDAO = new VeiculoDAO();
        return veiculosDAO.existeJuncaoPeca(veiculo, peca);
    }
    public List<Peca> pegarJuncaoPeca(Veiculo veiculo){
        VeiculoDAO veiculosDAO = new VeiculoDAO();
        return veiculosDAO.pegarJuncaoPeca(veiculo);
    }
}