package DTO;

public class Servico {
	
	private int id;
	private String entrada;
	private String saida;
	private double valorTotal;
	private Orcamento orcamento;
	private Cliente cliente;
	private Mecanico mecanico;
	
	public Servico() {
		super();
	}
	public Servico(int id, String entrada, String saida, double valorTotal, Orcamento orcamento, Cliente cliente, Mecanico mecanico) {
		super();
		this.id = id;
		this.entrada = entrada;
		this.saida = saida;
		this.valorTotal = valorTotal;
		this.orcamento = orcamento;
		this.cliente = cliente;
		this.mecanico = mecanico;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEntrada() {
		return entrada;
	}
	public void setEntrada(String entrada) {
		this.entrada = entrada;
	}
	public String getSaida() {
		return saida;
	}
	public void setSaida(String saida) {
		this.saida = saida;
	}
	public double getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(double valorTotal) {
		this.valorTotal = valorTotal;
	}
	public Orcamento getOrcamento() {
		return orcamento;
	}
	public void setOrcamento(Orcamento orcamento) {
		this.orcamento = orcamento;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public Mecanico getMecanico() {
		return mecanico;
	}
	public void setMecanico(Mecanico mecanico) {
		this.mecanico = mecanico;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Servico [id=");
		builder.append(id);
		builder.append(", entrada=");
		builder.append(entrada);
		builder.append(", saida=");
		builder.append(saida);
		builder.append(", valorTotal=");
		builder.append(valorTotal);
		builder.append(", orcamento=");
		builder.append(orcamento);
		builder.append(", cliente=");
		builder.append(cliente);
		builder.append(", mecanico=");
		builder.append(mecanico);
		builder.append("]");
		return builder.toString();
	}
	
}
