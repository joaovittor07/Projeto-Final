package BO;

import DTO.Mecanico;
import DAO.MecanicoDAO;
import java.util.List;

public class MecanicoBO {

    public boolean inserir(Mecanico mecanico){
        if (existe(mecanico) != true) {
            MecanicoDAO mecanicosDAO = new MecanicoDAO();
            return mecanicosDAO.inserir(mecanico);
        }
        return false;
    }
    public boolean alterar(Mecanico mecanico){
        MecanicoDAO mecanicosDAO = new MecanicoDAO();
        return mecanicosDAO.alterar(mecanico);
    }
    public boolean excluir(Mecanico mecanico){
        MecanicoDAO mecanicosDAO = new MecanicoDAO();
        return mecanicosDAO.excluir(mecanico);
    }
    public Mecanico procurarPorId(Mecanico mecanico){
        MecanicoDAO mecanicosDAO = new MecanicoDAO();
        return mecanicosDAO.procurarPorId(mecanico);
    }
    public Mecanico procurarPorNome(Mecanico mecanico){
        MecanicoDAO mecanicosDAO = new MecanicoDAO();
        return mecanicosDAO.procurarPorNome(mecanico);
    }
    public boolean existe(Mecanico mecanico){
        MecanicoDAO mecanicosDAO = new MecanicoDAO();
        return mecanicosDAO.existe(mecanico);
    }
    public List<Mecanico> pesquisarTodos(){
        MecanicoDAO mecanicosDAO = new MecanicoDAO();
        return mecanicosDAO.pesquisarTodos();
    }
}