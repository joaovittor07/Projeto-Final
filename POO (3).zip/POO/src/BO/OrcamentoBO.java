package BO;

import DTO.Orcamento;
import DTO.Peca;
import DAO.OrcamentoDAO;

import java.util.List;

public class OrcamentoBO {

    public boolean inserir(Orcamento orcamento){
        if (existe(orcamento) != true) {
            OrcamentoDAO orcamentosDAO = new OrcamentoDAO();
            return orcamentosDAO.inserir(orcamento);
        }
        return false;
    }
    public boolean alterar(Orcamento orcamento){
        OrcamentoDAO orcamentosDAO = new OrcamentoDAO();
        return orcamentosDAO.alterar(orcamento);
    }
    public boolean excluir(Orcamento orcamento){
        OrcamentoDAO orcamentosDAO = new OrcamentoDAO();
        return orcamentosDAO.excluir(orcamento);
    }
    public Orcamento procurarPorId(Orcamento orcamento){
        OrcamentoDAO orcamentosDAO = new OrcamentoDAO();
        return orcamentosDAO.procurarPorId(orcamento);
    }
    public boolean existe(Orcamento orcamento){
        OrcamentoDAO orcamentosDAO = new OrcamentoDAO();
        return orcamentosDAO.existe(orcamento);
    }
    public List<Orcamento> pesquisarTodos(){
        OrcamentoDAO orcamentosDAO = new OrcamentoDAO();
        return orcamentosDAO.pesquisarTodos();
    }

    public boolean inserirJuncaoPeca(Orcamento orcamento, Peca peca){
        if (existeJuncaoPeca(orcamento, peca) != true) {
            OrcamentoDAO orcamentosDAO = new OrcamentoDAO();
            return orcamentosDAO.inserirJuncaoPeca(orcamento, peca);
        }
        return false;
    }
    public boolean excluirJuncaoPeca(Orcamento orcamento){
        OrcamentoDAO orcamentosDAO = new OrcamentoDAO();
        return orcamentosDAO.excluirJuncaoPeca(orcamento);
    }
    public boolean excluirJuncaoPeca(Orcamento orcamento, Peca peca){
        OrcamentoDAO orcamentosDAO = new OrcamentoDAO();
        return orcamentosDAO.excluirJuncaoPeca(orcamento, peca);
    }
    public boolean existeJuncaoPeca(Orcamento orcamento, Peca peca){
        OrcamentoDAO orcamentosDAO = new OrcamentoDAO();
        return orcamentosDAO.existeJuncaoPeca(orcamento, peca);
    }
    public List<Peca> pegarJuncaoPeca(Orcamento orcamento){
        OrcamentoDAO orcamentosDAO = new OrcamentoDAO();
        return orcamentosDAO.pegarJuncaoPeca(orcamento);
    }
}