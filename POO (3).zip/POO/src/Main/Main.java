package Main;

import java.util.List;
import java.util.Scanner;

import BO.ClienteBO;
import BO.MecanicoBO;
import BO.OrcamentoBO;
import BO.PecaBO;
import BO.ServicoBO;
import BO.VeiculoBO;
import DTO.Cliente;
import DTO.Mecanico;
import DTO.Orcamento;
import DTO.Peca;
import DTO.Servico;
import DTO.Veiculo;

public class Main {
    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);

		int opcao = 0;
        int opcaoCRUD = 0;

        ClienteBO clienteBO = new ClienteBO();
        MecanicoBO mecanicoBO = new MecanicoBO();
        PecaBO pecaBO = new PecaBO();
        VeiculoBO veiculoBO = new VeiculoBO();
        OrcamentoBO orcamentoBO = new OrcamentoBO();
        ServicoBO servicoBO = new ServicoBO();

        do {

            System.out.println();
            System.out.println("Escolha uma opção:");
            System.out.println("0. Sair");
            System.out.println("1. CRUD Cliente");
            System.out.println("2. CRUD Mecanico");
            System.out.println("3. CRUD Peça");
            System.out.println("4. CRUD Veiculo");
            System.out.println("5. CRUD Orçamento");
            System.out.println("6. CRUD Serviço");
            System.out.println();
            
			opcao = s.nextInt();

            if (opcao == 1) {

                System.out.println("Escolha uma opção para Cliente:");
                System.out.println("0. Voltar");
                System.out.println("1. Listar");
                System.out.println("2. Listar Específico");
                System.out.println("3. Criar");
                System.out.println("4. Alterar");
                System.out.println("5. Deletar");

                opcaoCRUD = s.nextInt();

                if (opcaoCRUD == 1) {

                    List<Cliente> lista = clienteBO.pesquisarTodos();

                    for (Cliente l : lista) {

                        System.out.println(l.toString());
    
                    }

                } else if (opcaoCRUD == 2) {

                    System.out.println("Informe o nome do Cliente:");
                    String nome = s.next();

                    Cliente obj = new Cliente();
                    obj.setNome(nome);
                    obj = clienteBO.procurarPorNome(obj);
                    System.out.println(obj.toString());

                    List<Veiculo> todosVeiculos = veiculoBO.pesquisarTodos();

                    for (Veiculo veiculo : todosVeiculos) {

                        if (veiculo.getCliente().getId() == obj.getId()) {

                            obj.adicionarVeiculo(veiculo);

                        }

                    }

                    System.out.println("Veículos:");

                    for (Veiculo veiculo : obj.getVeiculos()) {
                        
                        System.out.println(veiculo.toString());

                    }

                    List<Orcamento> todosOrcamentos = orcamentoBO.pesquisarTodos();

                    for (Orcamento orcamento : todosOrcamentos) {

                        if (orcamento.getCliente().getId() == obj.getId()) {

                            obj.adicionarOrcamento(orcamento);

                        }

                    }

                    System.out.println("Orçamentos:");

                    for (Orcamento orcamento : obj.getOrcamentos()) {
                        
                        System.out.println(orcamento.toString());

                    }

                    List<Servico> todosServicos = servicoBO.pesquisarTodos();

                    for (Servico servico : todosServicos) {

                        if (servico.getCliente().getId() == obj.getId()) {

                            obj.adicionarServico(servico);

                        }

                    }

                    System.out.println("Serviços:");

                    for (Servico servico : obj.getServicos()) {
                        
                        System.out.println(servico.toString());

                    }
                    
                } else if (opcaoCRUD == 3) {

                    System.out.println("Informe o nome do Cliente:");
                    String nome = s.next();

                    System.out.println("Informe o email do Cliente:");
                    String email = s.next();

                    System.out.println("Informe a senha do Cliente:");
                    String senha = s.next();

                    System.out.println("Informe a data de nascimento do Cliente (AAAA-MM-DD):");
                    String dataNascimento = s.next();

                    Cliente obj = new Cliente(0, email, senha, dataNascimento, nome);

                    if (clienteBO.inserir(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }
                    
                } else if (opcaoCRUD == 4) {

                    System.out.println("Informe o nome do Cliente:");
                    String nome = s.next();

                    Cliente obj = new Cliente();
                    obj.setNome(nome);
                    obj = clienteBO.procurarPorNome(obj);

                    System.out.println("Informe o novo nome do Cliente:");
                    String nomeNovo = s.next();

                    System.out.println("Informe o novo email do Cliente:");
                    String email = s.next();

                    System.out.println("Informe a nova senha do Cliente:");
                    String senha = s.next();

                    System.out.println("Informe a nova data de nascimento do Cliente (AAAA-MM-DD):");
                    String dataNascimento = s.next();

                    obj.setNome(nomeNovo);
                    obj.setEmail(email);
                    obj.setSenha(senha);
                    obj.setDataNascimento(dataNascimento);

                    if (clienteBO.alterar(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }
                    
                } else if (opcaoCRUD == 5) {

                    System.out.println("Informe o nome do Cliente:");
                    String nome = s.next();

                    Cliente obj = new Cliente();
                    obj.setNome(nome);
                    obj = clienteBO.procurarPorNome(obj);

                    if (clienteBO.excluir(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }
                    
                }
                
            } else if (opcao == 2) {

                System.out.println("Escolha uma opção para Mecanico:");
                System.out.println("0. Voltar");
                System.out.println("1. Listar");
                System.out.println("2. Listar Específico");
                System.out.println("3. Criar");
                System.out.println("4. Alterar");
                System.out.println("5. Deletar");

                opcaoCRUD = s.nextInt();

                if (opcaoCRUD == 1) {

                    List<Mecanico> lista = mecanicoBO.pesquisarTodos();

                    for (Mecanico l : lista) {

                        System.out.println(l.toString());
    
                    }
                    
                } else if (opcaoCRUD == 2) {

                    System.out.println("Informe o nome do Mecanico:");
                    String nome = s.next();

                    Mecanico obj = new Mecanico();
                    obj.setNome(nome);
                    obj = mecanicoBO.procurarPorNome(obj);
                    System.out.println(obj.toString());

                    List<Servico> todosServicos = servicoBO.pesquisarTodos();

                    for (Servico servico : todosServicos) {

                        if (servico.getMecanico().getId() == obj.getId()) {

                            obj.adicionarServico(servico);

                        }

                    }

                    System.out.println("Serviços:");

                    for (Servico servico : obj.getServicos()) {
                        
                        System.out.println(servico.toString());

                    }
                    
                } else if (opcaoCRUD == 3) {

                    System.out.println("Informe o nome do Mecanico:");
                    String nome = s.next();

                    System.out.println("Informe o email do Mecanico:");
                    String email = s.next();

                    System.out.println("Informe a senha do Mecanico:");
                    String senha = s.next();

                    System.out.println("Informe a data de nascimento do Mecanico (AAAA-MM-DD):");
                    String dataNascimento = s.next();

                    Mecanico obj = new Mecanico(0, email, senha, dataNascimento, nome);

                    if (mecanicoBO.inserir(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }
                    
                } else if (opcaoCRUD == 4) {

                    System.out.println("Informe o nome do Mecanico:");
                    String nome = s.next();

                    Mecanico obj = new Mecanico();
                    obj.setNome(nome);
                    obj = mecanicoBO.procurarPorNome(obj);

                    System.out.println("Informe o novo nome do Mecanico:");
                    String nomeNovo = s.next();

                    System.out.println("Informe o novo email do Mecanico:");
                    String email = s.next();

                    System.out.println("Informe a nova senha do Mecanico:");
                    String senha = s.next();

                    System.out.println("Informe a nova data de nascimento do Mecanico (AAAA-MM-DD):");
                    String dataNascimento = s.next();

                    obj.setNome(nomeNovo);
                    obj.setEmail(email);
                    obj.setSenha(senha);
                    obj.setDataNascimento(dataNascimento);

                    if (mecanicoBO.alterar(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }
                    
                } else if (opcaoCRUD == 5) {

                    System.out.println("Informe o nome do Mecanico:");
                    String nome = s.next();

                    Mecanico obj = new Mecanico();
                    obj.setNome(nome);
                    obj = mecanicoBO.procurarPorNome(obj);

                    if (mecanicoBO.excluir(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }
                    
                }
                
            } else if (opcao == 3) {

                System.out.println("Escolha uma opção para Peça:");
                System.out.println("0. Voltar");
                System.out.println("1. Listar");
                System.out.println("2. Listar Específico");
                System.out.println("3. Criar");
                System.out.println("4. Alterar");
                System.out.println("5. Deletar");

                opcaoCRUD = s.nextInt();

                if (opcaoCRUD == 1) {

                    List<Peca> lista = pecaBO.pesquisarTodos();

                    for (Peca l : lista) {

                        System.out.println(l.toString());
    
                    }
                    
                } else if (opcaoCRUD == 2) {

                    System.out.println("Informe o id da Peça:");
                    int id = s.nextInt();

                    Peca obj = new Peca();
                    obj.setId(id);
                    obj = pecaBO.procurarPorId(obj);
                    System.out.println(obj.toString());
                    
                } else if (opcaoCRUD == 3) {

                    System.out.println("Informe o tipo da Peça:");
                    String tipoPeca = s.next();

                    System.out.println("Informe a quantidade de estoque da Peça:");
                    int quantidadeEstoque = s.nextInt();

                    System.out.println("Informe a marca da Peça:");
                    String marca = s.next();

                    System.out.println("Informe o preço da Peça:");
                    Double preco = s.nextDouble();

                    Peca obj = new Peca(0, tipoPeca, quantidadeEstoque, marca, preco);

                    if (pecaBO.inserir(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }
                    
                } else if (opcaoCRUD == 4) {

                    System.out.println("Informe o id da Peça:");
                    int id = s.nextInt();

                    Peca obj = new Peca();
                    obj.setId(id);
                    obj = pecaBO.procurarPorId(obj);

                    System.out.println("Informe o novo tipo da Peça:");
                    String tipoPeca = s.next();

                    System.out.println("Informe a nova quantidade de estoque da Peça:");
                    int quantidadeEstoque = s.nextInt();

                    System.out.println("Informe a nova marca da Peça:");
                    String marca = s.next();

                    System.out.println("Informe o novo preço da Peça:");
                    Double preco = s.nextDouble();

                    obj.setTipoPeca(tipoPeca);
                    obj.setQuantidadeEstoque(quantidadeEstoque);
                    obj.setMarca(marca);
                    obj.setPreco(preco);

                    if (pecaBO.alterar(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }
                    
                } else if (opcaoCRUD == 5) {

                    System.out.println("Informe o id da Peça:");
                    int id = s.nextInt();

                    Peca obj = new Peca();
                    obj.setId(id);
                    obj = pecaBO.procurarPorId(obj);

                    if (pecaBO.excluir(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }
                    
                }

            } else if (opcao == 4) {

                System.out.println("Escolha uma opção para Veiculo:");
                System.out.println("0. Voltar");
                System.out.println("1. Listar");
                System.out.println("2. Listar Específico");
                System.out.println("3. Criar");
                System.out.println("4. Alterar");
                System.out.println("5. Deletar");

                opcaoCRUD = s.nextInt();

                if (opcaoCRUD == 1) {

                    List<Veiculo> lista = veiculoBO.pesquisarTodos();

                    for (Veiculo l : lista) {

                        System.out.println(l.toString());
    
                    }
                    
                } else if (opcaoCRUD == 2) {

                    System.out.println("Informe o id do Veiculo:");
                    int id = s.nextInt();

                    Veiculo obj = new Veiculo();
                    obj.setId(id);
                    obj = veiculoBO.procurarPorId(obj);
                    System.out.println(obj.toString());

                    List<Orcamento> todosOrcamentos = orcamentoBO.pesquisarTodos();

                    for (Orcamento orcamento : todosOrcamentos) {

                        if (orcamento.getVeiculo().getId() == obj.getId()) {

                            obj.adicionarOrcamento(orcamento);

                        }

                    }

                    System.out.println("Orçamentos:");

                    for (Orcamento orcamento : obj.getOrcamentos()) {
                        
                        System.out.println(orcamento.toString());

                    }

                    obj.setPecas(veiculoBO.pegarJuncaoPeca(obj));

                    System.out.println("Peças:");

                    for (Peca peca : obj.getPecas()) {
                        
                        System.out.println(peca.toString());

                    }
                    
                } else if (opcaoCRUD == 3) {

                    System.out.println("Informe a marca do Veiculo:");
                    String marca = s.next();

                    System.out.println("Informe o tipo de combustivel do Veiculo:");
                    String tipoCombustivel = s.next();

                    System.out.println("Informe o tipo do motor do Veiculo:");
                    String tipoMotor = s.next();

                    System.out.println("Informe o nome do Cliente do Veiculo:");
                    String nome = s.next();

                    Cliente cliente = new Cliente();
                    cliente.setNome(nome);
                    cliente = clienteBO.procurarPorNome(cliente);

                    Veiculo obj = new Veiculo(0, marca, tipoCombustivel, tipoMotor, cliente);
                  
                    if (veiculoBO.inserir(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }
                    
                    int opcaoPeca = 0;

                    do {

                        System.out.println("Informe um id de Peça para adicionar ao Veiculo ou 0 para sair:");
                        opcaoPeca = s.nextInt();

                        if (opcaoPeca != 0) {

                            Peca peca = new Peca();
                            peca.setId(opcaoPeca);
                            peca = pecaBO.procurarPorId(peca);

                            if (veiculoBO.inserirJuncaoPeca(obj, peca)) {
                                
                                System.out.println("Sucesso");

                             } else {

                                System.out.println("Erro");

                            }

                        }
                        
                    } while (opcaoPeca != 0);

                    
                    
                } else if (opcaoCRUD == 4) {

                    System.out.println("Informe o id do Veiculo:");
                    int id = s.nextInt();

                    Veiculo obj = new Veiculo();
                    obj.setId(id);
                    obj = veiculoBO.procurarPorId(obj);

                    System.out.println("Informe a nova marca do Veiculo:");
                    String marca = s.next();

                    System.out.println("Informe o novo tipo de combustivel do Veiculo:");
                    String tipoCombustivel = s.next();

                    System.out.println("Informe o novo tipo do motor do Veiculo:");
                    String tipoMotor = s.next();

                    System.out.println("Informe o nome do novo Cliente do Veiculo:");
                    String nome = s.next();

                    Cliente cliente = new Cliente();
                    cliente.setNome(nome);
                    cliente = clienteBO.procurarPorNome(cliente);

                    obj.setMarca(marca);
                    obj.setTipoCombustivel(tipoCombustivel);
                    obj.setTipoMotor(tipoMotor);
                    obj.setCliente(cliente);

                    if (veiculoBO.alterar(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }
                    
                    int opcaoPeca = 0;

                    do {

                        System.out.println("Informe o id de uma nova Peça para adiciona-la ao Veiculo, o id de uma Peça existente para remove-la do Veiculo ou 0 para sair:");
                        opcaoPeca = s.nextInt();

                        if (opcaoPeca != 0) {

                            Peca peca = new Peca();
                            peca.setId(opcaoPeca);
                            peca = pecaBO.procurarPorId(peca);

                            if (veiculoBO.existeJuncaoPeca(obj, peca)) {

                                if (veiculoBO.excluirJuncaoPeca(obj, peca)) {

                                    System.out.println("Sucesso");

                                } else {

                                    System.out.println("Erro");

                                }
                                
                            } else {

                                if (veiculoBO.inserirJuncaoPeca(obj, peca)) {
                                
                                    System.out.println("Sucesso");

                                } else {

                                    System.out.println("Erro");

                                }

                            }

                        }
                        
                    } while (opcaoPeca != 0);

                                        
                } else if (opcaoCRUD == 5) {

                    System.out.println("Informe o id do Veiculo:");
                    int id = s.nextInt();

                    Veiculo obj = new Veiculo();
                    obj.setId(id);
                    obj = veiculoBO.procurarPorId(obj);

                    if (veiculoBO.excluirJuncaoPeca(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }

                    if (veiculoBO.excluir(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }
                    
                }
                
            } else if (opcao == 5) {

                System.out.println("Escolha uma opção para Orçamento:");
                System.out.println("0. Voltar");
                System.out.println("1. Listar");
                System.out.println("2. Listar Específico");
                System.out.println("3. Criar");
                System.out.println("4. Alterar");
                System.out.println("5. Deletar");

                opcaoCRUD = s.nextInt();

                if (opcaoCRUD == 1) {

                    List<Orcamento> lista = orcamentoBO.pesquisarTodos();

                    for (Orcamento l : lista) {

                        System.out.println(l.toString());
    
                    }
                    
                } else if (opcaoCRUD == 2) {

                    System.out.println("Informe o id do Orçamento:");
                    int id = s.nextInt();

                    Orcamento obj = new Orcamento();
                    obj.setId(id);
                    obj = orcamentoBO.procurarPorId(obj);
                    System.out.println(obj.toString());

                    obj.setPecas(orcamentoBO.pegarJuncaoPeca(obj));

                    System.out.println("Peças:");

                    for (Peca peca : obj.getPecas()) {
                        
                        System.out.println(peca.toString());

                    }
                    
                } else if (opcaoCRUD == 3) {

                    System.out.println("Informe o valor prescrito do Orçamento:");
                    double valorPrescrito = s.nextDouble();

                    System.out.println("Informe o nome do Cliente do Orçamento:");
                    String nome = s.next();

                    Cliente cliente = new Cliente();
                    cliente.setNome(nome);
                    cliente = clienteBO.procurarPorNome(cliente);

                    System.out.println("Informe o id do Veiculo do Orçamento:");
                    int id = s.nextInt();

                    Veiculo veiculo = new Veiculo();
                    veiculo.setId(id);
                    veiculo = veiculoBO.procurarPorId(veiculo);

                    Orcamento obj = new Orcamento(0, valorPrescrito, cliente, veiculo);

                    if (orcamentoBO.inserir(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }
                    
                    int opcaoPeca = 0;

                    do {

                        System.out.println("Informe um id de Peça para adicionar ao Veiculo ou 0 para sair:");
                        opcaoPeca = s.nextInt();

                        if (opcaoPeca != 0) {

                            Peca peca = new Peca();
                            peca.setId(opcaoPeca);
                            peca = pecaBO.procurarPorId(peca);

                            if (orcamentoBO.inserirJuncaoPeca(obj, peca)) {
                                
                                System.out.println("Sucesso");

                             } else {

                                System.out.println("Erro");

                            }

                        }
                        
                    } while (opcaoPeca != 0);

                                        
                } else if (opcaoCRUD == 4) {

                    System.out.println("Informe o id do Orçamento:");
                    int id = s.nextInt();

                    Orcamento obj = new Orcamento();
                    obj.setId(id);
                    obj = orcamentoBO.procurarPorId(obj);

                    System.out.println("Informe o novo valor prescrito do Orçamento:");
                    double valorPrescrito = s.nextDouble();

                    System.out.println("Informe o nome do novo Cliente do Orçamento:");
                    String nome = s.next();

                    Cliente cliente = new Cliente();
                    cliente.setNome(nome);
                    cliente = clienteBO.procurarPorNome(cliente);

                    System.out.println("Informe o id do novo Veiculo do Orçamento:");
                    int idNovo = s.nextInt();

                    Veiculo veiculo = new Veiculo();
                    veiculo.setId(idNovo);
                    veiculo = veiculoBO.procurarPorId(veiculo);

                    obj.setValorPrescrito(valorPrescrito);
                    obj.setCliente(cliente);
                    obj.setVeiculo(veiculo);
                   
                    if (orcamentoBO.alterar(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }
                    
                    int opcaoPeca = 0;

                    do {

                        System.out.println("Informe o id de uma nova Peça para adiciona-la ao Orçamento, o id de uma Peça existente para remove-la do Orçamento ou 0 para sair:");
                        opcaoPeca = s.nextInt();

                        if (opcaoPeca != 0) {

                            Peca peca = new Peca();
                            peca.setId(opcaoPeca);
                            peca = pecaBO.procurarPorId(peca);

                            if (orcamentoBO.existeJuncaoPeca(obj, peca)) {

                                if (orcamentoBO.excluirJuncaoPeca(obj, peca)) {

                                    System.out.println("Sucesso");

                                } else {

                                    System.out.println("Erro");

                                }
                                
                            } else {

                                if (orcamentoBO.inserirJuncaoPeca(obj, peca)) {
                                
                                    System.out.println("Sucesso");

                                } else {

                                    System.out.println("Erro");

                                }

                            }

                        }
                        
                    } while (opcaoPeca != 0);

                                        
                } else if (opcaoCRUD == 5) {

                    System.out.println("Informe o id do Orçamento:");
                    int id = s.nextInt();

                    Orcamento obj = new Orcamento();
                    obj.setId(id);
                    obj = orcamentoBO.procurarPorId(obj);

                    if (orcamentoBO.excluirJuncaoPeca(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }

                    if (orcamentoBO.excluir(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }
                    
                }
                
            } else if (opcao == 6) {

                System.out.println("Escolha uma opção para Serviço:");
                System.out.println("0. Voltar");
                System.out.println("1. Listar");
                System.out.println("2. Listar Específico");
                System.out.println("3. Criar");
                System.out.println("4. Alterar");
                System.out.println("5. Deletar");

                opcaoCRUD = s.nextInt();

                if (opcaoCRUD == 1) {

                    List<Servico> lista = servicoBO.pesquisarTodos();

                    for (Servico l : lista) {

                        System.out.println(l.toString());
    
                    }
                    
                } else if (opcaoCRUD == 2) {

                    System.out.println("Informe o id do Serviço:");
                    int id = s.nextInt();

                    Servico obj = new Servico();
                    obj.setId(id);
                    obj = servicoBO.procurarPorId(obj);
                    System.out.println(obj.toString());
                    
                } else if (opcaoCRUD == 3) {

                    System.out.println("Informe a data de entrada do Serviço (AAAA-MM-DD):");
                    String entrada = s.next();

                    System.out.println("Informe a data de saida do Serviço (AAAA-MM-DD):");
                    String saida = s.next();

                    System.out.println("Informe o valor total do Serviço:");
                    Double valorTotal = s.nextDouble();

                    System.out.println("Informe o id do Orçamento do Serviço:");
                    int id = s.nextInt();

                    Orcamento orcamento = new Orcamento();
                    orcamento.setId(id);
                    orcamento = orcamentoBO.procurarPorId(orcamento);

                    System.out.println("Informe o nome do Cliente do Serviço:");
                    String nomeCli = s.next();

                    Cliente cliente = new Cliente();
                    cliente.setNome(nomeCli);
                    cliente = clienteBO.procurarPorNome(cliente);

                    System.out.println("Informe o nome do Mecanico do Serviço:");
                    String nomeMec = s.next();

                    Mecanico mecanico = new Mecanico();
                    mecanico.setNome(nomeMec);
                    mecanico = mecanicoBO.procurarPorNome(mecanico);

                    Servico obj = new Servico(0, entrada, saida, valorTotal, orcamento, cliente, mecanico);

                    if (servicoBO.inserir(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }
                    
                } else if (opcaoCRUD == 4) {

                    System.out.println("Informe o id do Serviço:");
                    int id = s.nextInt();

                    Servico obj = new Servico();
                    obj.setId(id);
                    obj = servicoBO.procurarPorId(obj);

                    System.out.println("Informe a nova data de entrada do Serviço (AAAA-MM-DD):");
                    String entrada = s.next();

                    System.out.println("Informe a nova data de saida do Serviço (AAAA-MM-DD):");
                    String saida = s.next();

                    System.out.println("Informe o novo valor total do Serviço:");
                    Double valorTotal = s.nextDouble();

                    System.out.println("Informe o id do novo Orçamento do Serviço:");
                    int idOrc = s.nextInt();

                    Orcamento orcamento = new Orcamento();
                    orcamento.setId(idOrc);
                    orcamento = orcamentoBO.procurarPorId(orcamento);

                    System.out.println("Informe o nome do novo Cliente do Serviço:");
                    String nomeCli = s.next();

                    Cliente cliente = new Cliente();
                    cliente.setNome(nomeCli);
                    cliente = clienteBO.procurarPorNome(cliente);

                    System.out.println("Informe o nome do novo Mecanico do Serviço:");
                    String nomeMec = s.next();

                    Mecanico mecanico = new Mecanico();
                    mecanico.setNome(nomeMec);
                    mecanico = mecanicoBO.procurarPorNome(mecanico);

                    obj.setEntrada(entrada);
                    obj.setSaida(saida);
                    obj.setValorTotal(valorTotal);
                    obj.setOrcamento(orcamento);
                    obj.setCliente(cliente);
                    obj.setMecanico(mecanico);

                    if (servicoBO.alterar(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }
                    
                } else if (opcaoCRUD == 5) {

                    System.out.println("Informe o id do Serviço:");
                    int id = s.nextInt();

                    Servico obj = new Servico();
                    obj.setId(id);
                    obj = servicoBO.procurarPorId(obj);

                    if (servicoBO.excluir(obj)) {

                        System.out.println("Sucesso");

                    } else {

                        System.out.println("Erro");

                    }
                    
                }
                
            }
            
        } while (opcao != 0);
		s.close();
    }
}
