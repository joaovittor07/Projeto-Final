package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import BO.ClienteBO;
import BO.MecanicoBO;
import BO.OrcamentoBO;
import DTO.Cliente;
import DTO.Mecanico;
import DTO.Orcamento;
import DTO.Servico;
import Conexao.Conexao;

public class ServicoDAO {

    final String NOMEDATABELA = "servico";
    
    public boolean inserir(Servico servico) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "INSERT INTO " + NOMEDATABELA + " (entrada, saida, valortotal, orcamento_id, cliente_id, mecanico_id) VALUES (?, ?, ?, ?, ?, ?);";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, servico.getEntrada());
            ps.setString(2, servico.getSaida());
            ps.setDouble(3, servico.getValorTotal());
            ps.setInt(4, servico.getOrcamento().getId());
            ps.setInt(5, servico.getCliente().getId());
            ps.setInt(6, servico.getMecanico().getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean alterar(Servico servico) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "UPDATE " + NOMEDATABELA + " SET entrada = ?, saida = ?, valortotal = ?, orcamento_id = ?, cliente_id = ?, mecanico_id = ? WHERE id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, servico.getEntrada());
            ps.setString(2, servico.getSaida());
            ps.setDouble(3, servico.getValorTotal());
            ps.setInt(4, servico.getOrcamento().getId());
            ps.setInt(5, servico.getCliente().getId());
            ps.setInt(6, servico.getMecanico().getId());
            ps.setInt(7, servico.getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception e) {
        	 e.printStackTrace();
             return false;
        }
    }
    public boolean excluir(Servico servico) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "DELETE FROM " + NOMEDATABELA + " WHERE id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, servico.getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception e) {
        	 e.printStackTrace();
             return false;
        }
    }
    public Servico procurarPorId(Servico servico) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "SELECT * FROM " + NOMEDATABELA + " WHERE id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, servico.getId());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Servico obj = new Servico();
                obj.setId(rs.getInt(1));
                obj.setEntrada(rs.getString(2));
                obj.setSaida(rs.getString(3));
                obj.setValorTotal(rs.getDouble(4));
                OrcamentoBO orcametoBO = new OrcamentoBO();
                Orcamento orcamento = new Orcamento();
                orcamento.setId(rs.getInt(5));
                orcamento = orcametoBO.procurarPorId(orcamento);
                obj.setOrcamento(orcamento);
                ClienteBO clienteBO = new ClienteBO();
                Cliente cliente = new Cliente();
                cliente.setId(rs.getInt(6));
                cliente = clienteBO.procurarPorId(cliente);
                obj.setCliente(cliente);
                MecanicoBO mecanicoBO = new MecanicoBO();
                Mecanico mecanico = new Mecanico();
                mecanico.setId(rs.getInt(7));
                mecanico = mecanicoBO.procurarPorId(mecanico);
                obj.setMecanico(mecanico);
                ps.close();
                rs.close();
                conn.close();
                return obj;
            } else {
                ps.close();
                rs.close();
                conn.close();
                return null;
            }
        } catch (Exception e) {
        	 e.printStackTrace();
             return null;
        }
    }
    public boolean existe(Servico servico) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "SELECT * FROM " + NOMEDATABELA + " WHERE id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, servico.getId());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                ps.close();
                rs.close();
                conn.close();
                return true;
            }
        } catch (Exception e) {
           e.printStackTrace();
            return false;
        }
        return false;
    }
    public List<Servico> pesquisarTodos() {
        try {
            Connection conn = Conexao.conectar();
            String sql = "SELECT * FROM " + NOMEDATABELA + ";";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            List<Servico> listObj = montarLista(rs);
            return listObj;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public List<Servico> montarLista(ResultSet rs) {
        List<Servico> listObj = new ArrayList<Servico>();
        try {
            while (rs.next()) {
                Servico obj = new Servico();
                obj.setId(rs.getInt(1));
                obj.setEntrada(rs.getString(2));
                obj.setSaida(rs.getString(3));
                obj.setValorTotal(rs.getDouble(4));
                OrcamentoBO orcametoBO = new OrcamentoBO();
                Orcamento orcamento = new Orcamento();
                orcamento.setId(rs.getInt(5));
                orcamento = orcametoBO.procurarPorId(orcamento);
                obj.setOrcamento(orcamento);
                ClienteBO clienteBO = new ClienteBO();
                Cliente cliente = new Cliente();
                cliente.setId(rs.getInt(6));
                cliente = clienteBO.procurarPorId(cliente);
                obj.setCliente(cliente);
                MecanicoBO mecanicoBO = new MecanicoBO();
                Mecanico mecanico = new Mecanico();
                mecanico.setId(rs.getInt(7));
                mecanico = mecanicoBO.procurarPorId(mecanico);
                obj.setMecanico(mecanico);
                listObj.add(obj);
            }
            return listObj;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}