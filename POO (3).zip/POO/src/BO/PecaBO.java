package BO;

import DTO.Peca;
import DAO.PecaDAO;
import java.util.List;

public class PecaBO {

    public boolean inserir(Peca peca){
        if (existe(peca) != true) {
            PecaDAO pecasDAO = new PecaDAO();
            return pecasDAO.inserir(peca);
        }
        return false;
    }
    public boolean alterar(Peca peca){
        PecaDAO pecasDAO = new PecaDAO();
        return pecasDAO.alterar(peca);
    }
    public boolean excluir(Peca peca){
        PecaDAO pecasDAO = new PecaDAO();
        return pecasDAO.excluir(peca);
    }
    public Peca procurarPorId(Peca peca){
        PecaDAO pecasDAO = new PecaDAO();
        return pecasDAO.procurarPorId(peca);
    }
    public boolean existe(Peca peca){
        PecaDAO pecasDAO = new PecaDAO();
        return pecasDAO.existe(peca);
    }
    public List<Peca> pesquisarTodos(){
        PecaDAO pecasDAO = new PecaDAO();
        return pecasDAO.pesquisarTodos();
    }
}