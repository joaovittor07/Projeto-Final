package DTO;

import java.util.ArrayList;
import java.util.List;

public class Mecanico extends Usuario {

	private List<Servico> servicos = new ArrayList<Servico>();
	
	public void adicionarServico (Servico servico) {
		
		servicos.add(servico);
		
	}
	
	public Mecanico() {
		super();
	}
	public Mecanico(int id, String email, String senha, String dataNascimento, String nome) {
		super(id, email, senha, dataNascimento, nome);
	}
	public List<Servico> getServicos() {
		return servicos;
	}
	public void setServicos(List<Servico> servicos) {
		this.servicos = servicos;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Mecanico [getId()=");
		builder.append(getId());
		builder.append(", getEmail()=");
		builder.append(getEmail());
		builder.append(", getSenha()=");
		builder.append(getSenha());
		builder.append(", getNome()=");
		builder.append(getNome());
		builder.append(", getDataNascimento()=");
		builder.append(getDataNascimento());
		builder.append(", toString()=");
		builder.append(super.toString());
		builder.append(", getClass()=");
		builder.append(getClass());
		builder.append(", hashCode()=");
		builder.append(hashCode());
		builder.append("]");
		return builder.toString();
	}

}