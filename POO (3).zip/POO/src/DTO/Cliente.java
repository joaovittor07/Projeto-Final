package DTO;

import java.util.ArrayList;
import java.util.List;

public class Cliente extends Usuario {

	private List<Servico> servicos = new ArrayList<Servico>();
	
	public void adicionarServico (Servico servico) {
		
		servicos.add(servico);
		
	}
	
	private List<Veiculo> veiculos = new ArrayList<Veiculo>();
	
	public void adicionarVeiculo (Veiculo veiculo) {
		
		veiculos.add(veiculo);
		
	}
	
	private List<Orcamento> orcamentos = new ArrayList<Orcamento>();
	
	public void adicionarOrcamento (Orcamento orcamento) {
		
		orcamentos.add(orcamento);
		
	}
	
	public void removerOrcamento (int id) {
		
		orcamentos.remove(id);
		
	}
	
	public Cliente() {
		super();
	}
	public Cliente(int id, String email, String senha, String dataNascimento, String nome) {
		super(id, email, senha, dataNascimento, nome);
	}
	public List<Servico> getServicos() {
		return servicos;
	}
	public void setServicos(List<Servico> servicos) {
		this.servicos = servicos;
	}
	public List<Veiculo> getVeiculos() {
		return veiculos;
	}
	public void setVeiculos(List<Veiculo> veiculos) {
		this.veiculos = veiculos;
	}
	public List<Orcamento> getOrcamentos() {
		return orcamentos;
	}
	public void setOrcamentos(List<Orcamento> orcamentos) {
		this.orcamentos = orcamentos;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Cliente [getId()=");
		builder.append(getId());
		builder.append(", getEmail()=");
		builder.append(getEmail());
		builder.append(", getSenha()=");
		builder.append(getSenha());
		builder.append(", getNome()=");
		builder.append(getNome());
		builder.append(", getDataNascimento()=");
		builder.append(getDataNascimento());
		builder.append(", toString()=");
		builder.append(super.toString());
		builder.append(", getClass()=");
		builder.append(getClass());
		builder.append(", hashCode()=");
		builder.append(hashCode());
		builder.append("]");
		return builder.toString();
		
	}

}