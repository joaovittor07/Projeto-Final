package DTO;

public class Peca {

	private int id;
	private String tipoPeca;
	private int quantidadeEstoque;
	private String marca;
	private double preco;
	
	public Peca() {
		super();
	}
	public Peca(int id, String tipoPeca, int quantidadeEstoque, String marca, double preco) {
		super();
		this.id = id;
		this.tipoPeca = tipoPeca;
		this.quantidadeEstoque = quantidadeEstoque;
		this.marca = marca;
		this.preco = preco;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTipoPeca() {
		return tipoPeca;
	}
	public void setTipoPeca(String tipoPeca) {
		this.tipoPeca = tipoPeca;
	}
	public int getQuantidadeEstoque() {
		return quantidadeEstoque;
	}
	public void setQuantidadeEstoque(int quantidadeEstoque) {
		this.quantidadeEstoque = quantidadeEstoque;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Peca [id=");
		builder.append(id);
		builder.append(", tipoPeca=");
		builder.append(tipoPeca);
		builder.append(", quantidadeEstoque=");
		builder.append(quantidadeEstoque);
		builder.append(", marca=");
		builder.append(marca);
		builder.append(", preco=");
		builder.append(preco);
		builder.append("]");
		return builder.toString();
	}
	
}
