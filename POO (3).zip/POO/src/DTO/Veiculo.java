package DTO;

import java.util.ArrayList;
import java.util.List;

public class Veiculo {

	private int id;
	private String marca;
	private String tipoCombustivel;
	private String tipoMotor;
	private Cliente cliente;
	
	private List<Orcamento> orcamentos = new ArrayList<Orcamento>();
	
	private List<Peca> pecas = new ArrayList<Peca>();
	
	public void adicionarOrcamento (Orcamento orcamento) {
		
		orcamentos.add(orcamento);
		
	}
		
	public void adicionarPeca (Peca peca) {
		
		pecas.add(peca);
		
	}
	
	public Veiculo() {
		super();
	}
	public Veiculo(int id, String marca, String tipoCombustivel, String tipoMotor, Cliente cliente) {
		super();
		this.id = id;
		this.marca = marca;
		this.tipoCombustivel = tipoCombustivel;
		this.tipoMotor = tipoMotor;
		this.cliente = cliente;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getTipoCombustivel() {
		return tipoCombustivel;
	}
	public void setTipoCombustivel(String tipoCombustivel) {
		this.tipoCombustivel = tipoCombustivel;
	}
	public String getTipoMotor() {
		return tipoMotor;
	}
	public void setTipoMotor(String tipoMotor) {
		this.tipoMotor = tipoMotor;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Veiculo [id=");
		builder.append(id);
		builder.append(", marca=");
		builder.append(marca);
		builder.append(", tipoCombustivel=");
		builder.append(tipoCombustivel);
		builder.append(", tipoMotor=");
		builder.append(tipoMotor);
		builder.append(", cliente=");
		builder.append(cliente);
		builder.append("]");
		return builder.toString();
	}

	public List<Orcamento> getOrcamentos() {
		return orcamentos;
	}
	public void setOrcamentos(List<Orcamento> orcamentos) {
		this.orcamentos = orcamentos;
	}
	public List<Peca> getPecas() {
		return pecas;
	}
	public void setPecas(List<Peca> pecas) {
		this.pecas = pecas;
	}
	
}
