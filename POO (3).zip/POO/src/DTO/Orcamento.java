package DTO;

import java.util.ArrayList;
import java.util.List;

public class Orcamento {
	
	private int id;
	private double valorPrescrito;
	private Cliente cliente;
	private Veiculo veiculo;

	private List<Peca> pecas = new ArrayList<Peca>();
	
	public void adicionarPeca (Peca peca) {
		
		pecas.add(peca);
		
	}
	
	public double totalOrcamento() {
		
		double total = 0;
		
		for(Peca p : pecas) {
			
			total = total + p.getPreco();
			
		}
		
		return total;
		
	}
	
	public Orcamento() {
		super();
	}
	public Orcamento(int id, double valorPrescrito, Cliente cliente, Veiculo veiculo) {
		super();
		this.id = id;
		this.valorPrescrito = valorPrescrito;
		this.cliente = cliente;
		this.veiculo = veiculo;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getValorPrescrito() {
		return valorPrescrito;
	}
	public void setValorPrescrito(double valorPrescrito) {
		this.valorPrescrito = valorPrescrito;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public Veiculo getVeiculo() {
		return veiculo;
	}
	public void setVeiculo(Veiculo veiculo) {
		this.veiculo = veiculo;
	}
	public List<Peca> getPecas() {
		return pecas;
	}
	public void setPecas(List<Peca> pecas) {
		this.pecas = pecas;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Orcamento [id=");
		builder.append(id);
		builder.append(", valorPrescrito=");
		builder.append(valorPrescrito);
		builder.append(", cliente=");
		builder.append(cliente);
		builder.append(", veiculo=");
		builder.append(veiculo);
		builder.append(", totalOrcamento=");
		builder.append(totalOrcamento());
		builder.append("]");
		return builder.toString();
	}
	
}
