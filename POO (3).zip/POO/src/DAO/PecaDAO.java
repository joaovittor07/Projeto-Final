package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import DTO.Peca;
import Conexao.Conexao;

public class PecaDAO {

    final String NOMEDATABELA = "peca";
    
    public boolean inserir(Peca peca) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "INSERT INTO " + NOMEDATABELA + " (tipopeca, quantidadeestoque, marca, preco) VALUES (?, ?, ? ,?);";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, peca.getTipoPeca());
            ps.setInt(2, peca.getQuantidadeEstoque());
            ps.setString(3, peca.getMarca());
            ps.setDouble(4, peca.getPreco());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean alterar(Peca peca) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "UPDATE " + NOMEDATABELA + " SET tipopeca = ?, quantidadeestoque = ?, marca = ?, preco = ? WHERE id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, peca.getTipoPeca());
            ps.setInt(2, peca.getQuantidadeEstoque());
            ps.setString(3, peca.getMarca());
            ps.setDouble(4, peca.getPreco());
            ps.setInt(5, peca.getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception e) {
        	 e.printStackTrace();
             return false;
        }
    }
    public boolean excluir(Peca peca) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "DELETE FROM " + NOMEDATABELA + " WHERE id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, peca.getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception e) {
        	 e.printStackTrace();
             return false;
        }
    }
    public Peca procurarPorId(Peca peca) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "SELECT * FROM " + NOMEDATABELA + " WHERE id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, peca.getId());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Peca obj = new Peca();
                obj.setId(rs.getInt(1));
                obj.setTipoPeca(rs.getString(2));
                obj.setQuantidadeEstoque(rs.getInt(3));
                obj.setMarca(rs.getString(4));
                obj.setPreco(rs.getDouble(5));
                ps.close();
                rs.close();
                conn.close();
                return obj;
            } else {
                ps.close();
                rs.close();
                conn.close();
                return null;
            }
        } catch (Exception e) {
        	 e.printStackTrace();
             return null;
        }
    }
    public boolean existe(Peca peca) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "SELECT * FROM " + NOMEDATABELA + " WHERE id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, peca.getId());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                ps.close();
                rs.close();
                conn.close();
                return true;
            }
        } catch (Exception e) {
           e.printStackTrace();
            return false;
        }
        return false;
    }
    public List<Peca> pesquisarTodos() {
        try {
            Connection conn = Conexao.conectar();
            String sql = "SELECT * FROM " + NOMEDATABELA + ";";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            List<Peca> listObj = montarLista(rs);
            return listObj;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public List<Peca> montarLista(ResultSet rs) {
        List<Peca> listObj = new ArrayList<Peca>();
        try {
            while (rs.next()) {
                Peca obj = new Peca();
                obj.setId(rs.getInt(1));
                obj.setTipoPeca(rs.getString(2));
                obj.setQuantidadeEstoque(rs.getInt(3));
                obj.setMarca(rs.getString(4));
                obj.setPreco(rs.getDouble(5));
                listObj.add(obj);
            }
            return listObj;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}