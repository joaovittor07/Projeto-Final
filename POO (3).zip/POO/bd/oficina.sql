-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema oficina
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema oficina
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `oficina` DEFAULT CHARACTER SET utf8 ;
USE `oficina` ;

-- -----------------------------------------------------
-- Table `oficina`.`cliente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oficina`.`cliente` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(45) NULL,
  `senha` VARCHAR(45) NULL,
  `datanascimento` DATE NULL,
  `nome` VARCHAR(45) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `oficina`.`veiculo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oficina`.`veiculo` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `marca` VARCHAR(45) NULL,
  `tipocombustivel` VARCHAR(45) NULL,
  `tipomotor` VARCHAR(45) NULL,
  `cliente_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_veiculo_cliente_idx` (`cliente_id` ASC),
  CONSTRAINT `fk_veiculo_cliente`
    FOREIGN KEY (`cliente_id`)
    REFERENCES `oficina`.`cliente` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `oficina`.`orcamento`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oficina`.`orcamento` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `valorprescrito` DECIMAL(10,2) NULL,
  `cliente_id` INT NOT NULL,
  `veiculo_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_orcamento_cliente1_idx` (`cliente_id` ASC) ,
  INDEX `fk_orcamento_veiculo1_idx` (`veiculo_id` ASC) ,
  CONSTRAINT `fk_orcamento_cliente1`
    FOREIGN KEY (`cliente_id`)
    REFERENCES `oficina`.`cliente` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_orcamento_veiculo1`
    FOREIGN KEY (`veiculo_id`)
    REFERENCES `oficina`.`veiculo` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `oficina`.`peca`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oficina`.`peca` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `tipopeca` VARCHAR(45) NULL,
  `quantidadeestoque` INT NULL,
  `marca` VARCHAR(45) NULL,
  `preco` DECIMAL(10,2) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `oficina`.`mecanico`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oficina`.`mecanico` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(45) NULL,
  `senha` VARCHAR(45) NULL,
  `datanascimento` DATE NULL,
  `nome` VARCHAR(45) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `oficina`.`servico`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oficina`.`servico` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `entrada` DATE NULL,
  `saida` DATE NULL,
  `valortotal` DECIMAL(10,2) NULL,
  `orcamento_id` INT NOT NULL,
  `cliente_id` INT NOT NULL,
  `mecanico_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_servico_orcamento1_idx` (`orcamento_id` ASC),
  INDEX `fk_servico_cliente1_idx` (`cliente_id` ASC),
  INDEX `fk_servico_mecanico1_idx` (`mecanico_id` ASC),
  CONSTRAINT `fk_servico_orcamento1`
    FOREIGN KEY (`orcamento_id`)
    REFERENCES `oficina`.`orcamento` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_servico_cliente1`
    FOREIGN KEY (`cliente_id`)
    REFERENCES `oficina`.`cliente` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_servico_mecanico1`
    FOREIGN KEY (`mecanico_id`)
    REFERENCES `oficina`.`mecanico` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `oficina`.`veiculo_has_peca`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oficina`.`veiculo_has_peca` (
  `veiculo_id` INT NOT NULL,
  `peca_id` INT NOT NULL,
  PRIMARY KEY (`veiculo_id`, `peca_id`),
  INDEX `fk_veiculo_has_peca_peca1_idx` (`peca_id` ASC) ,
  INDEX `fk_veiculo_has_peca_veiculo1_idx` (`veiculo_id` ASC) ,
  CONSTRAINT `fk_veiculo_has_peca_veiculo1`
    FOREIGN KEY (`veiculo_id`)
    REFERENCES `oficina`.`veiculo` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_veiculo_has_peca_peca1`
    FOREIGN KEY (`peca_id`)
    REFERENCES `oficina`.`peca` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `oficina`.`orcamento_has_peca`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `oficina`.`orcamento_has_peca` (
  `orcamento_id` INT NOT NULL,
  `peca_id` INT NOT NULL,
  PRIMARY KEY (`orcamento_id`, `peca_id`),
  INDEX `fk_orcamento_has_peca_peca1_idx` (`peca_id` ASC) ,
  INDEX `fk_orcamento_has_peca_orcamento1_idx` (`orcamento_id` ASC) ,
  CONSTRAINT `fk_orcamento_has_peca_orcamento1`
    FOREIGN KEY (`orcamento_id`)
    REFERENCES `oficina`.`orcamento` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_orcamento_has_peca_peca1`
    FOREIGN KEY (`peca_id`)
    REFERENCES `oficina`.`peca` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
