package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import BO.ClienteBO;
import BO.VeiculoBO;
import DTO.Cliente;
import DTO.Orcamento;
import DTO.Peca;
import DTO.Veiculo;
import Conexao.Conexao;

public class OrcamentoDAO {

    final String NOMEDATABELA = "orcamento";
    final String NOMEDAJUNCAO = "orcamento_has_peca";
    
    public boolean inserir(Orcamento orcamento) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "INSERT INTO " + NOMEDATABELA + " (valorprescrito, cliente_id, veiculo_id) VALUES (?, ?, ?);";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setDouble(1, orcamento.getValorPrescrito());
            ps.setInt(2, orcamento.getCliente().getId());
            ps.setInt(3, orcamento.getVeiculo().getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean alterar(Orcamento orcamento) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "UPDATE " + NOMEDATABELA + " SET valorprescrito = ?, cliente_id = ?, veiculo_id = ? WHERE id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setDouble(1, orcamento.getValorPrescrito());
            ps.setInt(2, orcamento.getCliente().getId());
            ps.setInt(3, orcamento.getVeiculo().getId());
            ps.setInt(4, orcamento.getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception e) {
        	 e.printStackTrace();
             return false;
        }
    }
    public boolean excluir(Orcamento orcamento) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "DELETE FROM " + NOMEDATABELA + " WHERE id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, orcamento.getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception e) {
        	 e.printStackTrace();
             return false;
        }
    }
    public Orcamento procurarPorId(Orcamento orcamento) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "SELECT * FROM " + NOMEDATABELA + " WHERE id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, orcamento.getId());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Orcamento obj = new Orcamento();
                obj.setId(rs.getInt(1));
                obj.setValorPrescrito(rs.getDouble(2));
                ClienteBO clienteBO = new ClienteBO();
                Cliente cliente = new Cliente();
                cliente.setId(rs.getInt(3));
                cliente = clienteBO.procurarPorId(cliente);
                obj.setCliente(cliente);
                VeiculoBO veiculoBO = new VeiculoBO();
                Veiculo veiculo = new Veiculo();
                veiculo.setId(rs.getInt(4));
                veiculo = veiculoBO.procurarPorId(veiculo);
                obj.setVeiculo(veiculo);
                ps.close();
                rs.close();
                conn.close();
                return obj;
            } else {
                ps.close();
                rs.close();
                conn.close();
                return null;
            }
        } catch (Exception e) {
        	 e.printStackTrace();
             return null;
        }
    }
    public boolean existe(Orcamento orcamento) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "SELECT * FROM " + NOMEDATABELA + " WHERE id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, orcamento.getId());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                ps.close();
                rs.close();
                conn.close();
                return true;
            }
        } catch (Exception e) {
           e.printStackTrace();
            return false;
        }
        return false;
    }
    public List<Orcamento> pesquisarTodos() {
        try {
            Connection conn = Conexao.conectar();
            String sql = "SELECT * FROM " + NOMEDATABELA + ";";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            List<Orcamento> listObj = montarLista(rs);
            return listObj;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public List<Orcamento> montarLista(ResultSet rs) {
        List<Orcamento> listObj = new ArrayList<Orcamento>();
        try {
            while (rs.next()) {
                Orcamento obj = new Orcamento();
                obj.setId(rs.getInt(1));
                obj.setValorPrescrito(rs.getDouble(2));
                ClienteBO clienteBO = new ClienteBO();
                Cliente cliente = new Cliente();
                cliente.setId(rs.getInt(3));
                cliente = clienteBO.procurarPorId(cliente);
                obj.setCliente(cliente);
                VeiculoBO veiculoBO = new VeiculoBO();
                Veiculo veiculo = new Veiculo();
                veiculo.setId(rs.getInt(4));
                veiculo = veiculoBO.procurarPorId(veiculo);
                obj.setVeiculo(veiculo);
                listObj.add(obj);
            }
            return listObj;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean inserirJuncaoPeca(Orcamento orcamento, Peca peca) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "INSERT INTO " + NOMEDAJUNCAO + " (orcamento_id, peca_id) VALUES (?, ?);";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, orcamento.getId());
            ps.setInt(2, peca.getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean excluirJuncaoPeca(Orcamento orcamento) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "DELETE FROM " + NOMEDAJUNCAO + " WHERE orcamento_id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, orcamento.getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception e) {
        	 e.printStackTrace();
             return false;
        }
    }
    public boolean excluirJuncaoPeca(Orcamento orcamento, Peca peca) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "DELETE FROM " + NOMEDAJUNCAO + " WHERE orcamento_id = ? AND peca_id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, orcamento.getId());
            ps.setInt(2, peca.getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception e) {
        	 e.printStackTrace();
             return false;
        }
    }
    public boolean existeJuncaoPeca(Orcamento orcamento, Peca peca) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "SELECT * FROM " + NOMEDAJUNCAO + " WHERE orcamento_id = ? AND peca_id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, orcamento.getId());
            ps.setInt(2, peca.getId());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                ps.close();
                rs.close();
                conn.close();
                return true;
            }
        } catch (Exception e) {
           e.printStackTrace();
            return false;
        }
        return false;
    }
    public List<Peca> pegarJuncaoPeca(Orcamento orcamento) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "SELECT * FROM " + NOMEDAJUNCAO + " WHERE orcamento_id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, orcamento.getId());
            ResultSet rs = ps.executeQuery();
            List<Peca> listObj = montarListaJuncaoPeca(rs);
            return listObj;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public List<Peca> montarListaJuncaoPeca(ResultSet rs) {
        List<Peca> listObj = new ArrayList<Peca>();
        try {
            while (rs.next()) {
                Peca obj = new Peca();
                obj.setId(rs.getInt(1));
                obj.setTipoPeca(rs.getString(2));
                obj.setQuantidadeEstoque(rs.getInt(3));
                obj.setMarca(rs.getString(4));
                obj.setPreco(rs.getDouble(5));
                listObj.add(obj);
            }
            return listObj;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}