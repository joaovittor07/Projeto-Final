package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import BO.ClienteBO;
import DTO.Cliente;
import DTO.Peca;
import DTO.Veiculo;
import Conexao.Conexao;

public class VeiculoDAO {

    final String NOMEDATABELA = "veiculo";
    final String NOMEDAJUNCAO = "veiculo_has_peca";
    
    public boolean inserir(Veiculo veiculo) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "INSERT INTO " + NOMEDATABELA + " (marca, tipocombustivel, tipomotor, cliente_id) VALUES (?, ?, ?, ?);";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, veiculo.getMarca());
            ps.setString(2, veiculo.getTipoCombustivel());
            ps.setString(3, veiculo.getTipoMotor());
            ps.setInt(4, veiculo.getCliente().getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean alterar(Veiculo veiculo) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "UPDATE " + NOMEDATABELA + " SET marca = ?, tipocombustivel = ?, tipomotor = ?, cliente_id = ? WHERE id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, veiculo.getMarca());
            ps.setString(2, veiculo.getTipoCombustivel());
            ps.setString(3, veiculo.getTipoMotor());
            ps.setInt(4, veiculo.getCliente().getId());
            ps.setInt(5, veiculo.getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception e) {
        	 e.printStackTrace();
             return false;
        }
    }
    public boolean excluir(Veiculo veiculo) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "DELETE FROM " + NOMEDATABELA + " WHERE id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, veiculo.getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception e) {
        	 e.printStackTrace();
             return false;
        }
    }
    public Veiculo procurarPorId(Veiculo veiculo) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "SELECT * FROM " + NOMEDATABELA + " WHERE id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, veiculo.getId());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Veiculo obj = new Veiculo();
                obj.setId(rs.getInt(1));
                obj.setMarca(rs.getString(2));
                obj.setTipoCombustivel(rs.getString(3));
                obj.setTipoMotor(rs.getString(4));
                ClienteBO clienteBO = new ClienteBO();
                Cliente cliente = new Cliente();
                cliente.setId(rs.getInt(5));
                cliente = clienteBO.procurarPorId(cliente);
                obj.setCliente(cliente);
                ps.close();
                rs.close();
                conn.close();
                return obj;
            } else {
                ps.close();
                rs.close();
                conn.close();
                return null;
            }
        } catch (Exception e) {
        	 e.printStackTrace();
             return null;
        }
    }
    public boolean existe(Veiculo veiculo) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "SELECT * FROM " + NOMEDATABELA + " WHERE id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, veiculo.getId());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                ps.close();
                rs.close();
                conn.close();
                return true;
            }
        } catch (Exception e) {
           e.printStackTrace();
            return false;
        }
        return false;
    }
    public List<Veiculo> pesquisarTodos() {
        try {
            Connection conn = Conexao.conectar();
            String sql = "SELECT * FROM " + NOMEDATABELA + ";";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            List<Veiculo> listObj = montarLista(rs);
            return listObj;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public List<Veiculo> montarLista(ResultSet rs) {
        List<Veiculo> listObj = new ArrayList<Veiculo>();
        try {
            while (rs.next()) {
                Veiculo obj = new Veiculo();
                obj.setId(rs.getInt(1));
                obj.setMarca(rs.getString(2));
                obj.setTipoCombustivel(rs.getString(3));
                obj.setTipoMotor(rs.getString(4));
                ClienteBO clienteBO = new ClienteBO();
                Cliente cliente = new Cliente();
                cliente.setId(rs.getInt(5));
                cliente = clienteBO.procurarPorId(cliente);
                obj.setCliente(cliente);
                listObj.add(obj);
            }
            return listObj;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean inserirJuncaoPeca(Veiculo veiculo, Peca peca) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "INSERT INTO " + NOMEDAJUNCAO + " (veiculo_id, peca_id) VALUES (?, ?);";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, veiculo.getId());
            ps.setInt(2, peca.getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean excluirJuncaoPeca(Veiculo veiculo) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "DELETE FROM " + NOMEDAJUNCAO + " WHERE veiculo_id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, veiculo.getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception e) {
        	 e.printStackTrace();
             return false;
        }
    }
    public boolean excluirJuncaoPeca(Veiculo veiculo, Peca peca) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "DELETE FROM " + NOMEDAJUNCAO + " WHERE veiculo_id = ? AND peca_id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, veiculo.getId());
            ps.setInt(2, peca.getId());
            ps.executeUpdate();
            ps.close();
            conn.close();
            return true;
        } catch (Exception e) {
        	 e.printStackTrace();
             return false;
        }
    }
    public boolean existeJuncaoPeca(Veiculo veiculo, Peca peca) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "SELECT * FROM " + NOMEDAJUNCAO + " WHERE veiculo_id = ? AND peca_id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, veiculo.getId());
            ps.setInt(2, peca.getId());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                ps.close();
                rs.close();
                conn.close();
                return true;
            }
        } catch (Exception e) {
           e.printStackTrace();
            return false;
        }
        return false;
    }
    public List<Peca> pegarJuncaoPeca(Veiculo veiculo) {
        try {
            Connection conn = Conexao.conectar();
            String sql = "SELECT * FROM " + NOMEDAJUNCAO + " WHERE veiculo_id = ?;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, veiculo.getId());
            ResultSet rs = ps.executeQuery();
            List<Peca> listObj = montarListaJuncaoPeca(rs);
            return listObj;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public List<Peca> montarListaJuncaoPeca(ResultSet rs) {
        List<Peca> listObj = new ArrayList<Peca>();
        try {
            while (rs.next()) {
                Peca obj = new Peca();
                obj.setId(rs.getInt(1));
                obj.setTipoPeca(rs.getString(2));
                obj.setQuantidadeEstoque(rs.getInt(3));
                obj.setMarca(rs.getString(4));
                obj.setPreco(rs.getDouble(5));
                listObj.add(obj);
            }
            return listObj;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}